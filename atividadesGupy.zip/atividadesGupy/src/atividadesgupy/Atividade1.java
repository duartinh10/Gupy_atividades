/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividadesgupy;
import java.util.Scanner;
/**
 *
 * @author mathe
 */
public class Atividade1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner ler = new Scanner(System.in);
        int numero;
        int seq = 100;
        int cont = 0;
        
        System.out.println("Informe um numero:");
        numero = ler.nextInt();
        for(int i = 0; i < seq;i++)
        {
            cont = cont + i;
            
            if(cont == numero){
                System.out.println("Numero "+numero+" presente");
                break;
            }
            
        }
        if(cont != numero){
            System.out.println("Numero "+numero+" não presente");
        }
        
        }
    }
    

