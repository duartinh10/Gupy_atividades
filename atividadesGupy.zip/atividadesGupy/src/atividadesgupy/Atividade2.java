package atividadesgupy;
import java.util.Scanner;

public class Atividade2 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        String palavra;
        int cont = 0;

        System.out.println("Digite qualquer palavra: ");
        palavra = ler.next();  // Lê a palavra digitada pelo usuário
        
        // Percorre cada caractere da string
        for (int i = 0; i < palavra.length(); i++) {
            if (palavra.charAt(i) == 'a' || palavra.charAt(i) == 'A') 
            {  // Verifica se o caractere é 'a' ou 'A'
                cont++;
            }
        }

        System.out.println("Quantidade de letras 'a': " + cont);
    }
}
